import { auth,db,storage} from "./firebase.js";
import { collection,onSnapshot, doc, updateDoc,addDoc,setDoc  } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-firestore.js";
import { ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-storage.js";


window.addProduct=async()=>{
let name=document.getElementById("name").value;
let description=document.getElementById("description").value;
let price=document.getElementById("price").value;
let qty=document.getElementById("qty").value;
let file=document.getElementById("file");

try {
    const docRef = await addDoc(collection(db, "product"), {
   name,
   description,
   price,
   qty,
   pic:""
    });
    console.log("Document written with ID: ", docRef.id);
    const storageRef = ref(storage, `product/${docRef.id}`);

    const uploadTask = uploadBytesResumable(storageRef, file.files[0]);
    uploadTask.on('state_changed', 
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log('Upload is ' + progress + '% done');
        switch (snapshot.state) {
          case 'paused':
            console.log('Upload is paused');
            break;
          case 'running':
            console.log('Upload is running');
            break;
        }
      }, 
      (error) => {
console.log(error);
      }, 
      () => {
     
        getDownloadURL(uploadTask.snapshot.ref).then(async(downloadURL) => {
          console.log('File available at', downloadURL);
      
          await setDoc(doc(db, "product", docRef.id), {
            name,
            description,
            price,
            qty,
            pic:downloadURL
          });
          
      }
    
    )
    })

  } catch (e) {
    console.error("Error adding document: ", e);
  }

}