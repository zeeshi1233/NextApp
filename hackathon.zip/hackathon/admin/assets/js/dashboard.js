import { auth,db,storage} from "./firebase.js";
import { onAuthStateChanged  } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-auth.js";
import { collection,onSnapshot  } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-storage.js";

onAuthStateChanged(auth, (user) => {
    if (user) {   
      const uid = user.uid;

      const q =collection(db, "admin");
 onSnapshot(q, (snapshot) => {
  snapshot.docChanges().forEach((change) => {
   if (uid==change.doc.data().id) {
    document.getElementById("uname").innerHTML=change.doc.data().name
    document.getElementById("uname2").innerHTML=change.doc.data().name
   }
  });
});

    } else {
window.location.href='../pages/sign-in.html';
    }
  });